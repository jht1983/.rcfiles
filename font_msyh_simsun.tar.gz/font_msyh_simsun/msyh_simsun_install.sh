sudo mkdir -pv /usr/share/fonts/truetype/windows
sudo cp *.ttf /usr/share/fonts/truetype/windows
cd /usr/share/fonts/truetype/windows
sudo chmod 755 *
sudo mkfontscale
sudo mkfontdir
sudo fc-cache -fv

